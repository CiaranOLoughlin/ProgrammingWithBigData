import array

__author__ = 'Ciaran'
import matplotlib.pyplot as plt
import pandas as pd

language = "French"

cols=['Letter', 'Language', 'Frequency']
df = pd.read_csv('C:/Users/Ciaran/PycharmProjects/ProgrammingWithBigData/CsvInput/frequencyDistributionJob-' + language + '-r-00000', names=cols, sep='\t', header=None, dtype = {'Letter': str,'Language': str,
                                                      'Frequency': float})
ax = df.plot(kind='line', x='Letter', y='Frequency', label='French')
language = "Spanish"
df = pd.read_csv('C:/Users/Ciaran/PycharmProjects/ProgrammingWithBigData/CsvInput/frequencyDistributionJob-' + language + '-r-00000', names=cols, sep='\t', header=None, dtype = {'Letter': str,'Language': str,
                                                      'Frequency': float})

ax = df.plot(kind='line', ax = ax, x='Letter', y='Frequency', label='Spanish')
language = "English"
df = pd.read_csv('C:/Users/Ciaran/PycharmProjects/ProgrammingWithBigData/CsvInput/frequencyDistributionJob-' + language + '-r-00000', names=cols, sep='\t', header=None, dtype = {'Letter': str,'Language': str,
                                                      'Frequency': float})
df.plot(kind='bar', ax = ax,  x='Letter', y='Frequency', label='English')

plt.show()
