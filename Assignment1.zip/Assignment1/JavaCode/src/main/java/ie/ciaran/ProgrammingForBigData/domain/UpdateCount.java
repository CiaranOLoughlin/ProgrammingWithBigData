package ie.ciaran.ProgrammingForBigData.domain;

public enum UpdateCount{
    CNT
}
